#ifndef CMAKE_TUTORIAL_MATH_H
#define CMAKE_TUTORIAL_MATH_H

namespace math {

int add(int a, int b);
int sub(int a, int b);
int mul(int a, int b);

}

#endif
